"""
@file dmcan_def.py
@brief libdmcan 2.0.x 对外 C ABI 的 ctypes 类型、常量与回调原型。

布局的真源是 C++ SDK 的 `include/dmcan/dmcan_types.h` 与 `include/dmcan/dmcan.h`；下面每个
类型都标了 **C 侧结构体名与 sizeof 实测值**（用 MinGW x86_64 对头文件编译 `sizeof`/`offsetof`
量出来的，对拍脚本见 `tools/abi_check.py`）。字段偏移对不上会**静默读到垃圾数据**，改动前先跑对拍。

@note 2.0.0 起对外 ABI 与 v1.x 完全不兼容：v1.x 的 `usb_rx_frame_t`、`dmcan_ch_can_config_t`、
      `dmcan_device_get_version(handle, char *, size_t)` 在这一版都已改名或改布局。
"""

from ctypes import *
from enum import IntEnum, IntFlag

# ---------------------------------------------------------------- 对拍的 ABI 版本
DMCAN_ABI_MAJOR = 2
"""本绑定对拍的 libdmcan 主版本；结构体布局的主版本分界，库不匹配时 `DmCanContext` 直接拒绝。"""

DMCAN_ABI_MINOR = 1
"""本绑定对拍的 libdmcan 次版本。

2.1.0 是**破坏性**改动（`version_info_t` 被 `dmcan_firmware_info_t` 取代，字段变多变大），
所以绑定要求**至少** 2.1；`DmCanContext` 的闸门按“主版本相等 且 次版本不低于本值”判定。
"""

DMCAN_ABI_HINT = f"{DMCAN_ABI_MAJOR}.{DMCAN_ABI_MINOR}.x"
"""报错信息里用的版本描述，例如 `2.0.x`。"""


class dmcan_device_type(IntEnum):
    """设备型号（`dmcan_device_type_t`）。"""

    USB2CANFD_S = 0
    """USB2CANFD 单路（v1.x 里叫 `USB2CANFD`）"""
    USB2CANFD_D = 1
    """USB2CANFD 双路（v1.x 里叫 `USB2CANFD_DUAL`）"""
    LINKX4C = 2
    """LinkX4C"""
    UNKNOWN = 3
    """未识别型号（2.0 新增取值）"""


class dmcan_status(IntEnum):
    """`dmcan_get_last_error()` 的错误码（`dmcan_status_t`；后续只允许在尾部追加取值）。"""

    OK = 0
    """上一次调用成功"""
    INVALID_ARG = 1
    """入参非法（空指针、通道号越界、长度装不下等）"""
    NOT_OPEN = 2
    """设备尚未 open（或已 close）"""
    DEVICE_NOT_FOUND = 3
    """设备索引越界 / 当前没有设备"""
    NO_MEMORY = 4
    """内存不足"""
    IO = 5
    """与设备交互失败（USB 超时 / 固件拒绝）"""
    UNSUPPORTED = 6
    """设备或固件不支持该能力"""
    INTERNAL = 7
    """内部状态异常（不该发生）"""
    REENTRANT = 8
    """在 SDK 自己的回调线程上调用了会阻塞的接口（调用被拒绝，设备状态未变）"""


def status_of(code: int):
    """
    @brief 把原始错误码转成 `dmcan_status`；未收录（比本绑定新）的取值原样返回整数。

    @param code `dmcan_get_last_error()` 的原始返回值
    @return `dmcan_status` 成员，或未收录的整数
    """
    return dmcan_status._value2member_map_.get(code, code)


def device_type_of(value: int):
    """
    @brief 把 C 侧的型号枚举转成 `dmcan_device_type`；未收录的取值原样返回整数。

    @param value `dmcan_device_type_t` 的原始值
    @return `dmcan_device_type` 成员，或未收录的整数
    """
    return dmcan_device_type._value2member_map_.get(value, value)


class DmCanError(Exception):
    """
    @brief SDK 调用失败时抛出的异常，携带 `dmcan_get_last_error()` 的错误码。

    @note 错误码是**线程局部**的，异常在调用点就地构造，因此 `status` 就是本次调用失败的原因。
    """

    def __init__(self, status, api: str = ""):
        """
        @param status `dmcan_status` 成员，或未收录的原始错误码
        @param api 出错的接口名，便于在多层调用里定位
        """
        self.status = status
        self.api = api
        if isinstance(status, dmcan_status):
            # OK 只会在"接口返回 false 但库没置错误码"时出现（例如固件不上报版本名），
            # 直接打 OK 会让人以为是成功，这里说清楚。
            name = "接口返回 false 且未置错误码" if status == dmcan_status.OK else status.name
        else:
            name = f"未知错误码 {status}"
        super().__init__(f"{api} 失败: {name}" if api else name)


class version_t(Structure):
    """固件版本号（`version_t`，3B）。"""

    _pack_ = 1
    _fields_ = [
        ("major", c_uint8),
        ("minor", c_uint8),
        ("build", c_uint8),
    ]


class dmcan_firmware_info(Structure):
    """
    设备型号 + 固件发布版本 + 构建标识（`dmcan_firmware_info_t`，49B）。

    @note 两个 `*_valid` 分别表示“这次读到了没有”：为假时对应字段保持零值（版本 0.0.0 / 空串），
          不会回上一次读到的旧值。
    @note 判“板子是否还停在 boot”看 `version_valid`（boot 没有 app 的发布版本号）；
          判“升级是否生效”看 `build_id`（发布版本号在连续几版之间常常不变）。
    @note 2.1 的破坏性改动：它取代了 2.0.1 的 `version_info_t`（7B）。
    """

    _pack_ = 1
    _fields_ = [
        ("device", c_int),
        ("version", version_t),
        ("version_valid", c_bool),
        ("build_id", c_char * 40),
        ("build_id_valid", c_bool),
    ]


class dmcan_channel_can_info(Structure):
    """
    通道波特率（`dmcan_channel_can_info_t`，19B；**不含 TDC**）。

    @note `channel` 是接口的**函数参数**，不在结构体里（这一点与 v1.x 不同）；`non_iso` 与
          `retrans` 是 2.0 新增的开关。TDC 的开关不在这里，要用 `get_channel_baudrate_details()`。
    """

    _pack_ = 1
    _fields_ = [
        ("canfd", c_bool),
        ("non_iso", c_bool),
        ("retrans", c_bool),
        ("can_baudrate", c_uint32),
        ("canfd_baudrate", c_uint32),
        ("can_sp", c_float),
        ("canfd_sp", c_float),
    ]


class dmcan_channel_mode(IntEnum):
    """
    通道的 MCAN 节点模式（`dmcan_channel_mode_t`，2.1 新增；填进 `dmcan_ch_baud_conf.mode`）。

    @note 与固件/HPM 驱动的 `mcan_node_mode_t` 同口径，SDK 只透传。
    """

    NORMAL = 0
    """正常收发（默认）"""
    LOOPBACK_INTERNAL = 1
    """内部回环：TX 不外发，帧在芯片内回到接收路径（总线不动）"""
    LOOPBACK_EXTERNAL = 2
    """外部回环：帧照常驱动总线并回环到自己；**不依赖外部 ACK**，单模块即可自发自收"""
    LISTEN_ONLY = 3
    """只听不发（不驱动总线、不回 ACK）"""


class dmcan_ch_baud_conf(Structure):
    """
    通道位定时完整配置（`dmcan_ch_baud_conf_t`，22B，与固件布局逐字节一致）。

    @note `tdc_offset` / `tdc_filter` 只有低 7 位有效：0 表示自动（offset 取 `DTSEG1+2`，
          filter 跟随 offset），1~127 为指定值；`reserved` 必须填 0。
    """

    _pack_ = 1
    _fields_ = [
        ("enable_canfd", c_uint8, 1),
        ("enable_tdc", c_uint8, 1),
        ("non_iso", c_uint8, 1),
        ("enable_retrans", c_uint8, 1),
        ("mode", c_uint8, 4),  # 节点模式，取值见 dmcan_channel_mode（默认 0 = 正常收发）
        ("nominal_brp", c_uint16),
        ("nominal_seg1", c_uint16),
        ("nominal_seg2", c_uint16),
        ("nominal_sjw", c_uint16),
        ("data_brp", c_uint16),
        ("data_seg1", c_uint16),
        ("data_seg2", c_uint16),
        ("data_sjw", c_uint16),
        ("busoff_autoreset_ms", c_uint16),
        ("tdc_offset", c_uint8),
        ("tdc_filter", c_uint8),
        ("reserved", c_uint8),
    ]


class dmcan_rx_frame(Structure):
    """
    回调收到的帧（`dmcan_rx_frame_t`，84B）。

    @note 方向不由结构体给出：收帧走 recv 回调，发送回执走 sent 回调（`ack` 区分假/真 echo）。
    @note 指针由 SDK 持有，**只在本次回调期间有效**，要留存请自己拷一份。
    @note `dlen` 是**字节长度**（不是 DLC 码），`payload` 前 `dlen` 字节有效。
    """

    _pack_ = 1
    _fields_ = [
        ("can_id", c_uint32),
        ("timestamp", c_uint64),
        ("channel", c_uint8),
        ("ext", c_uint8),
        ("rtr", c_uint8),
        ("canfd", c_uint8),
        ("brs", c_uint8),
        ("esi", c_uint8),
        ("ack", c_uint8),
        ("dlen", c_uint8),
        ("payload", c_uint8 * 64),
    ]

    def __str__(self) -> str:
        """@brief 一行可读描述，便于日志与用例断言。"""
        length = min(self.dlen, 64)
        data = " ".join(f"{self.payload[i]:02X}" for i in range(min(length, 8)))
        if length > 8:
            data += " ..."
        tags = ["FD" if self.canfd else "CL"]
        for flag, name in ((self.brs, "BRS"), (self.esi, "ESI"), (self.rtr, "RTR"), (self.ack, "ACK")):
            if flag:
                tags.append(name)
        return (f"ID:{'E' if self.ext else 'S'}{self.can_id:08X} TS:{self.timestamp} CH:{self.channel} "
                f"{' '.join(tags)} DLEN:{length} DATA:[{data}]")

    def show(self) -> None:
        """@brief 打印该帧（等价于 `print(frame)`）。"""
        print(self)


class dmcan_frame(Structure):
    """
    批量发送用的一帧（`dmcan_frame_t`，76B；主机侧结构，**不按 1 字节对齐**）。

    @note `payload` 里 `dlen` 之外的字节被忽略；`dlen` 不在 DLC 表里时由 SDK 自动向上取整
          到最近的 DLC（尾部补 0）。
    """

    _fields_ = [
        ("can_id", c_uint32),
        ("canfd", c_bool),
        ("ext", c_bool),
        ("rtr", c_bool),
        ("brs", c_bool),
        ("dlen", c_uint8),
        ("payload", c_uint8 * 64),
    ]

    @classmethod
    def create(cls, can_id: int, payload: bytes = b"", canfd: bool = False, ext: bool = False,
               rtr: bool = False, brs: bool = False) -> "dmcan_frame":
        """
        @brief 由 ID 与数据构造一帧，`dlen` 取数据实际长度。

        @param can_id 帧 ID（标准帧 ≤ 0x7FF，扩展帧 ≤ 0x1FFFFFFF）
        @param payload 数据（0~64 字节）；`rtr` 为真时被忽略（远程帧不带数据）
        @param canfd 是否 CAN FD 帧
        @param ext 是否扩展帧
        @param rtr 是否远程帧
        @param brs 是否启用 BRS（仅 CAN FD 有意义）
        @return 填好的 `dmcan_frame`
        """
        frame = cls()
        data = b"" if rtr else bytes(payload)
        frame.can_id = can_id
        frame.canfd = canfd
        frame.ext = ext
        frame.rtr = rtr
        frame.brs = brs
        frame.dlen = len(data)
        frame.payload[: len(data)] = data
        return frame


class dmcan_bulk_send_config(Structure):
    """
    批量/递增发送配置（`dmcan_bulk_send_config_t`，40B；主机侧结构，**不按 1 字节对齐**）。

    @note `payload` 是裸指针。用 `create()` 构造时缓冲区挂在实例的 `_payload_ref` 上，
          实例活着指针就有效；手工赋值则要自己保证缓冲区生命周期。
    """

    _fields_ = [
        ("interval_ms", c_uint32),
        ("send_times", c_uint32),
        ("can_id", c_uint32),
        ("id_inc", c_bool),
        ("step_id", c_uint16),
        ("stop_id", c_uint32),
        ("data_inc", c_bool),
        ("canfd", c_bool),
        ("ext", c_bool),
        ("rtr", c_bool),
        ("brs", c_bool),
        ("dlen", c_uint8),
        ("payload", POINTER(c_uint8)),
    ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._payload_ref = None
        """@brief 持有 `payload` 指向的 ctypes 缓冲，避免被回收成野指针。"""

    @classmethod
    def create(cls, can_id: int, payload: bytes = b"", interval_ms: int = 0, send_times: int = 1,
               id_inc: bool = False, step_id: int = 1, stop_id: int = 0, data_inc: bool = False,
               canfd: bool = False, ext: bool = False, rtr: bool = False, brs: bool = False,
               dlen=None) -> "dmcan_bulk_send_config":
        """
        @brief 构造递增/周期发送配置，并接管 payload 缓冲区的生命周期。

        @param can_id 起始 ID
        @param payload 数据（0~64 字节）；`rtr` 为真时被忽略
        @param interval_ms 发送间隔，单位毫秒；0 = 只发一帧
        @param send_times 发送次数；0 = 不限（此时由 `stop_id` 决定何时停）
        @param id_inc 是否每帧 ID 递增 `step_id`，发送区间 `[can_id, stop_id)`
        @param step_id ID 步进；仅 `id_inc` 时有效
        @param stop_id 停止 ID（不含）；仅 `id_inc` 时有效
        @param data_inc 是否把 payload 当小端无符号整数逐帧 +1（与 ID 递增相互独立）
        @param dlen 数据长度；`None` 表示取 `payload` 的实际长度
        @return 填好的配置对象
        """
        config = cls()
        data = b"" if rtr else bytes(payload)
        config.interval_ms = interval_ms
        config.send_times = send_times
        config.can_id = can_id
        config.id_inc = id_inc
        config.step_id = step_id
        config.stop_id = stop_id
        config.data_inc = data_inc
        config.canfd = canfd
        config.ext = ext
        config.rtr = rtr
        config.brs = brs
        config.dlen = len(data) if dlen is None else dlen
        config._payload_ref = payload_buffer(data)
        config.payload = cast(config._payload_ref, POINTER(c_uint8))
        return config


class dmcan_context(Structure):
    """不透明上下文（`dmcan_context`）；只在 Python 侧当指针用，不要解引用。"""

    pass


class dmcan_device_handle(Structure):
    """不透明设备句柄（`dmcan_device_handle`）；只在 Python 侧当指针用，不要解引用。"""

    pass


DEV_RECV_CALLBACK = CFUNCTYPE(None, POINTER(dmcan_device_handle), POINTER(dmcan_rx_frame))
"""收帧回调（`dev_recv_callback`）：`(handle, frame)`，frame 只在本次回调期间有效。"""

DEV_SENT_CALLBACK = CFUNCTYPE(None, POINTER(dmcan_device_handle), POINTER(dmcan_rx_frame))
"""发送回执回调（`dev_sent_callback`）：同一帧会来两条，`frame.ack` 0 = 假 echo（USB 提交完成）、
1 = 真 echo（已上总线），顺序恒为 0 → 1。"""

DEV_ERR_CALLBACK = CFUNCTYPE(None, POINTER(dmcan_device_handle), POINTER(dmcan_rx_frame))
"""错误回调（`dev_err_callback`）：16B `dmcan_channel_error_t` 原样装在 `dlen = 16` 的帧里
（`payload` 前 16 字节），与 v1.x 逐字节一致。"""


def payload_buffer(data: bytes):
    """
    @brief 把字节序列转成 C 侧 `uint8_t *` 需要的 ctypes 数组。

    @param data 待发送数据；空序列得到长度 0 的数组（C 侧按 0 长度帧处理）
    @return c_uint8 数组；**调用期间必须保持引用**（放在调用方的局部变量里）
    """
    return (c_uint8 * len(data))(*data)


# ======================================================================================
# 诊断 / 订阅 / UART / 过滤 / 热插拔（2.0 新增面）
# 布局真源同上，sizeof 与关键偏移由 tools/abi_check.py 对拍
# ======================================================================================


class dmcan_send_profile(IntEnum):
    """发送聚合档位（`dmcan_send_profile_t`）。"""

    THROUGHPUT = 0
    """吞吐优先（默认，等价于历史行为）"""
    LOW_LATENCY = 1
    """延迟优先：攒批更小、帧到得更快，代价是 USB 笔数更多"""


class dmcan_event_flag(IntFlag):
    """订阅事件位图（`dmcan_event_flag_t`，可按位或组合）。"""

    RX_FRAME = 1 << 0
    """总线收到的帧"""
    TX_COMPLETED = 1 << 1
    """假 echo：这笔 USB 提交已完成"""
    TX_ON_BUS = 1 << 2
    """真 echo：固件回报该帧已在总线上被确认"""
    CHANNEL_ERROR = 1 << 3
    """通道错误记录"""
    UART_RX = 1 << 4
    """USB2UART 收到数据"""


DMCAN_CHANNEL_MASK_ALL = 0xFFFFFFFF
"""全部通道的掩码；**0 表示什么都没选**（属参数错）。"""


class dmcan_module_feature(IntFlag):
    """模块能力位（`CMD_GET_MODULE_INFO` 应答里的位定义；老固件/老硬件一律为 0）。"""

    CAN_RES_SW = 1 << 0
    """支持软件开关终端电阻（`dmcan_device_enable_can_res`）"""


DMCAN_DROP_FLAG_RX_ECHO = 0x01
"""`dmcan_channel_stats::drop_flags` bit0：接收/echo 侧细分记录已收到。"""

DMCAN_DROP_FLAG_TX = 0x02
"""`dmcan_channel_stats::drop_flags` bit1：发送侧细分记录已收到。"""

DMCAN_FILTER_RULE_MAX = 32
"""单张过滤表的规则条数上限。"""
DMCAN_FILTER_STD_RULE_MAX = 16
"""标准 ID 规则条数上限。"""
DMCAN_FILTER_EXT_RULE_MAX = 16
"""扩展 ID 规则条数上限。"""


class dmcan_filter_id_type(IntEnum):
    """过滤规则的 ID 类型（`dmcan_filter_id_type_t`）。"""

    STD = 0
    """标准帧（11 位 ID）"""
    EXT = 1
    """扩展帧（29 位 ID）"""


class dmcan_filter_type(IntEnum):
    """过滤规则的匹配类型（`dmcan_filter_rule_type_t`）。"""

    RANGE = 0
    """范围：`id1 ≤ rx_id ≤ id2`"""
    DUAL_ID = 1
    """双 ID 精确：等于 `id1` 或 `id2`"""
    MASK = 2
    """掩码：`(rx_id & id2) == (id1 & id2)`"""


class dmcan_filter_action(IntEnum):
    """过滤规则的命中动作（`dmcan_filter_action_t`）。"""

    FIFO0 = 0
    """存 RX FIFO0（正常接收）"""
    REJECT = 1
    """拒收"""
    PRIORITY = 2
    """置优先级并存 RX FIFO0"""


class dmcan_filter_mode(IntEnum):
    """过滤表的匹配模式（`dmcan_filter_mode_t`）。"""

    WHITELIST = 0
    """白名单：未命中任何规则 → 拒收（空表会拒收所有帧）"""
    BLACKLIST = 1
    """黑名单：未命中 → 正常接收（出厂默认）"""


class dmcan_hotplug_event(IntEnum):
    """热插拔事件类型（`dmcan_hotplug_event_t`）。"""

    ATTACHED = 0
    """设备接入"""
    DETACHED = 1
    """设备移除"""


class dmcan_tdc_status(Structure):
    """
    通道 TDC 的**硬件实际生效值**（`dmcan_tdc_status_t`，4B）。

    @note `valid` 为假说明"没读到"（老固件应答不含此字段 / 经典 CAN / 未启用 TDC），
          此时其余字段的 0 不是"生效值是 0"。
    @note 下发与生效不同步：`CMD_SETUP_BAUD` 只写 RAM 并置重载标志，实测 0.086 ~ 1.0 s 才生效。
    """

    _pack_ = 1
    _fields_ = [
        ("valid", c_bool),
        ("tdco", c_uint8),
        ("tdcf", c_uint8),
        ("tdcv", c_uint8),
    ]


class dmcan_channel_ext_config(Structure):
    """通道扩展配置（`dmcan_channel_ext_config_t`，3B）。"""

    _pack_ = 1
    _fields_ = [
        ("enable_retrans", c_uint8),
        ("busoff_autoreset_ms", c_uint16),
    ]


class dmcan_channel_error(Structure):
    """
    通道错误记录（`dmcan_channel_error_t`，16B，与固件逐字节一致）。

    @note `flags` 是"最近一次错误中断的原因位"，`bus_state` 才是"上报快照生成时的恢复结果"，
          两者不是同一时点。
    """

    _pack_ = 1
    _fields_ = [
        ("timestamp_us", c_uint64),
        ("error_code", c_uint16),
        ("bus_state", c_uint8),
        ("lec", c_uint8),
        ("dlec", c_uint8),
        ("tec", c_uint8),
        ("rec", c_uint8),
        ("flags", c_uint8),
    ]


class dmcan_echo_stats(Structure):
    """
    echo 诊断计数（`dmcan_echo_stats_t`，24B；只给计数，不产生逐帧事件）。

    @note 计数在"设备打开"期间累计，重新打开后从 0 开始。
    """

    _pack_ = 1
    _fields_ = [
        ("timeout_count", c_uint64),
        ("late_discarded", c_uint64),
        ("pending", c_uint32),
        ("timeout_ms", c_uint32),
    ]


class dmcan_bus_state(Structure):
    """通道总线状态快照（`dmcan_bus_state_t`，5B）。"""

    _pack_ = 1
    _fields_ = [
        ("bus_state", c_uint8),
        ("tec", c_uint8),
        ("rec", c_uint8),
        ("credits", c_uint8),
        ("in_flight", c_uint8),
    ]


class dmcan_channel_stats(Structure):
    """
    通道统计快照（`dmcan_channel_stats_t`，70B）。

    @note 值来自固件的**周期上报**（每秒一条），最多旧 1 秒。
    @note 先看 `drop_flags` 再信细分字段：位为 0 表示那条记录还没到过，
          **对应字段恒 0 并不代表"没丢过帧"**。
    """

    _pack_ = 1
    _fields_ = [
        ("tx_admitted", c_uint32),
        ("tx_completed", c_uint32),
        ("tx_dropped", c_uint32),
        ("tx_failed", c_uint32),
        ("rx_received", c_uint32),
        ("rx_dropped", c_uint32),
        ("sw_tx_fifo_level", c_uint16),
        ("hw_tx_fifo_level", c_uint16),
        ("enabled", c_uint8),
        ("reserved", c_uint8),
        ("drop_flags", c_uint8),
        ("reserved2", c_uint8 * 3),
        ("rx_dropped_queue", c_uint32),
        ("rx_dropped_msgc", c_uint32),
        ("echo_dropped_queue", c_uint32),
        ("echo_dropped_msgc", c_uint32),
        ("echo_sent", c_uint32),
        ("tx_dropped_no_credit", c_uint32),
        ("tx_dropped_queue_full", c_uint32),
        ("tx_dropped_submit_fail", c_uint32),
        ("tx_dropped_ch_disabled", c_uint32),
    ]


class dmcan_uart_config(Structure):
    """
    UART 线参数（`dmcan_uart_config_t`，8B）。

    @note `baud_rate = 0` 表示**不改**线参数（沿用设备当前配置）；默认是 115200 8N1。
    """

    _pack_ = 1
    _fields_ = [
        ("baud_rate", c_uint32),
        ("data_bits", c_uint8),
        ("parity", c_uint8),
        ("stop_bits", c_uint8),
        ("reserved", c_uint8),
    ]

    @classmethod
    def create(cls, baud_rate: int = 115200, data_bits: int = 8, parity: int = 0,
               stop_bits: int = 1) -> "dmcan_uart_config":
        """
        @brief 按常用参数构造线参数（默认 115200 8N1）。

        @param baud_rate 波特率；0 = 不改（沿用设备当前配置）
        @param data_bits 数据位，5~8
        @param parity 校验：0=无 1=奇 2=偶
        @param stop_bits 停止位，1 或 2
        @return 填好的 `dmcan_uart_config`
        """
        config = cls()
        config.baud_rate = baud_rate
        config.data_bits = data_bits
        config.parity = parity
        config.stop_bits = stop_bits
        return config


class dmcan_uart_stats(Structure):
    """UART 统计（`dmcan_uart_stats_t`，32B）。"""

    _pack_ = 1
    _fields_ = [
        ("rx_bytes", c_uint64),
        ("tx_bytes", c_uint64),
        ("rx_dropped", c_uint64),
        ("errors", c_uint32),
        ("is_open", c_uint8),
        ("reserved", c_uint8 * 3),
    ]


class dmcan_filter_rule(Structure):
    """单条过滤规则（`dmcan_filter_rule_t`，12B）。"""

    _pack_ = 1
    _fields_ = [
        ("id_type", c_uint8),
        ("type", c_uint8),
        ("action", c_uint8),
        ("reserved", c_uint8),
        ("id1", c_uint32),
        ("id2", c_uint32),
    ]

    @classmethod
    def create(cls, id_type, type_, action, id1: int, id2: int = 0) -> "dmcan_filter_rule":
        """
        @brief 构造一条规则；`reserved` 必须为 0（非 0 会被固件回 `NACK_ARG_ERR`）。

        @param id_type `dmcan_filter_id_type` 取值
        @param type_ `dmcan_filter_type` 取值（命名带下划线，避开 Python 内建 `type`）
        @param action `dmcan_filter_action` 取值
        @param id1 标准帧 ≤ 0x7FF，扩展帧 ≤ 0x1FFFFFFF
        @param id2 含义随 `type_` 变化；取值范围同 `id1`
        @return 填好的 `dmcan_filter_rule`
        """
        rule = cls()
        rule.id_type = int(id_type)
        rule.type = int(type_)
        rule.action = int(action)
        rule.reserved = 0
        rule.id1 = id1
        rule.id2 = id2
        return rule


class dmcan_filter_usage(Structure):
    """`CMD_SET_FILTER` 应答里的用量（`dmcan_filter_usage_t`，2B）。"""

    _pack_ = 1
    _fields_ = [
        ("std_used", c_uint8),
        ("ext_used", c_uint8),
    ]


class dmcan_filter_table(Structure):
    """整张过滤表（`dmcan_filter_table_t`，389B）；只有 `rules[0:count]` 有效。"""

    _pack_ = 1
    _fields_ = [
        ("mode", c_uint8),
        ("std_max", c_uint8),
        ("ext_max", c_uint8),
        ("count", c_uint16),
        ("rules", dmcan_filter_rule * DMCAN_FILTER_RULE_MAX),
    ]


class dmcan_uart_chunk(Structure):
    """UART 收数据的事件负载（`dmcan_uart_chunk_t`，16B）。"""

    _pack_ = 1
    _fields_ = [
        ("data", POINTER(c_uint8)),
        ("length", c_uint32),
        ("reserved", c_uint32),
    ]


class dmcan_event(Structure):
    """
    订阅事件的 C 侧结构（`dmcan_event_t`，40B）。

    @note `frame` / `error` / `uart` 指向 SDK 内部缓冲，**只在本次回调期间有效**，
          本绑定对外给的是拷好的 `DmCanEvent`，不把这个结构直接交给用户。
    """

    _fields_ = [
        ("type", c_int),
        ("channel", c_uint8),
        ("reserved", c_uint8 * 3),
        ("frame", POINTER(dmcan_rx_frame)),
        ("error", POINTER(dmcan_channel_error)),
        ("uart", POINTER(dmcan_uart_chunk)),
        ("reserved2", POINTER(c_void_p) * 1),
    ]


class dmcan_subscribe_config(Structure):
    """订阅配置（`dmcan_subscribe_config_t`，24B）。"""

    _fields_ = [
        ("events", c_uint32),
        ("channel_mask", c_uint32),
        ("callback", c_void_p),
        ("user_data", c_void_p),
    ]


class dmcan_hotplug_device(Structure):
    """热插拔事件里的设备描述（`dmcan_hotplug_device_t`，16B）。"""

    _fields_ = [
        ("type", c_int),
        ("vendor_id", c_int),
        ("product_id", c_int),
        ("bus_number", c_uint8),
        ("port_number", c_uint8),
    ]


class dmcan_subscription(Structure):
    """不透明的订阅句柄（`dmcan_subscription_t`）；只作指针用。"""

    pass


class dmcan_log_subscription(Structure):
    """不透明的日志订阅句柄（`dmcan_log_subscription_t`）；只作指针用。"""

    pass


class DmCanEvent:
    """
    @brief 交给用户的事件对象（从 `dmcan_event_t` **拷好**的副本）。

    @note 与 C 侧不同，这里不做零拷贝：指针只在回调期间有效，所以帧/错误/UART 数据都已拷贝，
          回调返回后再用也安全。
    """

    __slots__ = ("type", "channel", "frame", "error", "uart")

    def __init__(self, type_, channel: int, frame=None, error=None, uart=None):
        """
        @param type_ `dmcan_event_flag` 里的单个位
        @param channel 事件所属通道
        @param frame 帧类事件（RX / TX 两类）的 `dmcan_rx_frame` 副本，其余为 `None`
        @param error 错误事件的 `dmcan_channel_error` 副本，其余为 `None`
        @param uart UART 事件的字节副本（`bytes`），其余为 `None`
        """
        self.type = type_
        self.channel = channel
        self.frame = frame
        self.error = error
        self.uart = uart

    def __repr__(self) -> str:
        body = self.frame if self.frame is not None else (self.error if self.error is not None else self.uart)
        return f"<DmCanEvent {self.type!r} ch={self.channel} {body!r}>"


class DmCanDeviceInfo:
    """设备枚举信息（`dmcan_device_get_info()` 的结果）。"""

    __slots__ = ("device_type", "pid", "vid", "serial")

    def __init__(self, device_type, pid: int, vid: int, serial: str):
        """
        @param device_type `dmcan_device_type` 取值
        @param pid USB PID
        @param vid USB VID
        @param serial 序列号（已从 C 侧内部缓冲拷成 `str`）
        """
        self.device_type = device_type
        self.pid = pid
        self.vid = vid
        self.serial = serial

    def __repr__(self) -> str:
        return (f"<DmCanDeviceInfo {self.device_type.name if isinstance(self.device_type, dmcan_device_type) else self.device_type}"
                f" pid=0x{self.pid:04X} vid=0x{self.vid:04X} serial={self.serial!r}>")


class DmCanHotplugDevice:
    """热插拔事件里的设备描述（`dmcan_hotplug_device_t` 的结果对象）。"""

    __slots__ = ("type", "vendor_id", "product_id", "bus_number", "port_number")

    def __init__(self, type_, vendor_id: int, product_id: int, bus_number: int, port_number: int):
        """
        @param type_ `dmcan_device_type` 取值
        @param vendor_id USB VID
        @param product_id USB PID
        @param bus_number 总线号
        @param port_number 端口号（本机后端拿不到时恒 0）
        """
        self.type = type_
        self.vendor_id = vendor_id
        self.product_id = product_id
        self.bus_number = bus_number
        self.port_number = port_number

    def __repr__(self) -> str:
        return (f"<DmCanHotplugDevice {self.type} vid=0x{self.vendor_id:04X} pid=0x{self.product_id:04X}"
                f" bus={self.bus_number} port={self.port_number}>")


DEV_EVENT_CALLBACK = CFUNCTYPE(None, POINTER(dmcan_device_handle), POINTER(dmcan_event), c_void_p)
"""订阅事件回调（`dmcan_event_callback`）：`(handle, event, user_data)`，事件指针只在回调期间有效。"""

LOG_CALLBACK = CFUNCTYPE(None, c_int, c_ulonglong, c_char_p, c_void_p)
"""日志回调（`dmcan_log_callback`）：`(level, seq, line, user_data)`；`line` 只在回调期间有效。"""

HOTPLUG_CALLBACK = CFUNCTYPE(None, POINTER(dmcan_context), c_int, POINTER(dmcan_hotplug_device), c_void_p)
"""热插拔回调（`dmcan_hotplug_callback`）：`(ctx, event, device, user_data)`。"""
