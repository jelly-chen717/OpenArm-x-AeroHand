"""
@file dmcan_context.py
@brief DmCanContext：后端动态库的查找/加载、版本闸门与设备枚举（`dmcan_context_*` / `dmcan_find_devices`）。

@note 库文件名与 v1.x 不同：现在是 `libdmcan.dll`（MinGW）/ `dmcan.dll`（MSVC）/ `libdmcan.so` /
      `libdmcan.dylib`，v1.x 时代的 `libdm_device.dll` 已不存在。
"""

import os
import sys
from ctypes import *
from pathlib import Path
from typing import Any, Callable, Dict, Optional

from dmcan.dmcan_def import (DMCAN_ABI_HINT, DMCAN_ABI_MAJOR, DMCAN_ABI_MINOR, DmCanError,
                             DmCanHotplugDevice, HOTPLUG_CALLBACK, LOG_CALLBACK, device_type_of,
                             dmcan_context, dmcan_device_handle, dmcan_device_type,
                             dmcan_hotplug_event, dmcan_log_subscription, dmcan_status, status_of)
from dmcan.dmcan_device import DmCanDevice

ENV_LIBRARY_PATH = "DMCAN_LIBRARY_PATH"
"""环境变量名：直接指定后端动态库的完整路径，优先级高于自动查找。"""


class DmCanLogSubscription:
    """一次日志订阅的句柄：`cancel()` 注销。"""

    def __init__(self, dll, subscription, wrapper):
        """
        @param dll 已加载的 libdmcan
        @param subscription C 侧日志订阅句柄
        @param wrapper 回调外壳；**必须持有**，被回收会让 C 侧的函数指针变成野指针
        """
        self._dll = dll
        self._subscription = subscription
        self._wrapper = wrapper
        self._active = True

    @property
    def active(self) -> bool:
        """@brief 订阅是否仍然有效（`cancel()` 之后为 False）。"""
        return self._active

    def cancel(self) -> None:
        """@brief 注销日志订阅（可重复调用）。"""
        if self._active:
            self._dll.dmcan_remove_log_callback(self._subscription)
            self._active = False


def _library_names() -> tuple:
    """
    @brief 当前平台要找的后端动态库文件名（按顺序尝试）。

    @return 文件名元组
    """
    if sys.platform == "win32":
        return ("libdmcan.dll", "dmcan.dll")
    if sys.platform == "darwin":
        return ("libdmcan.dylib",)
    return ("libdmcan.so",)


def find_backend_dll_path() -> str:
    """
    @brief 查找后端动态库路径。

    查找顺序：环境变量 `DMCAN_LIBRARY_PATH` → `dmcan/dlls/` → 仓库根 `dlls/` → 当前工作目录 →
    交给系统搜索路径（此时只返回文件名）。

    @return 库路径；一处都没找到时返回文件名本身，加载失败会由 `DmCanContext` 报出明确异常
    """
    names = _library_names()

    override = os.environ.get(ENV_LIBRARY_PATH)
    if override:
        return override

    package_dir = Path(__file__).resolve().parent
    for directory in (package_dir / "dlls", package_dir.parent / "dlls", Path.cwd()):
        for name in names:
            candidate = directory / name
            if candidate.exists():
                return str(candidate)

    return names[0]


class DmCanContext:
    """SDK 上下文：加载后端库、枚举设备、按下标取设备句柄。"""

    def __init__(self, dll_path: Optional[str] = None):
        """
        @param dll_path 后端动态库路径；`None` 表示按 `find_backend_dll_path()` 自动查找

        @note 加载后会校验库的 major.minor 与本绑定是否一致（2.0.x 内结构体布局不变）；
              不配套直接抛 `RuntimeError`——继续用只会读到错位的数据。
        """
        self.dll_path = dll_path or find_backend_dll_path()
        self._devices: Dict[int, DmCanDevice] = {}
        self._ctx = POINTER(dmcan_context)()
        self._dll_directory = None
        self._hotplug_wrapper = None

        if sys.platform == "win32":
            directory = os.path.dirname(os.path.abspath(self.dll_path))
            if os.path.isdir(directory):
                # 句柄必须持有到进程结束：被回收时该目录会立刻从 DLL 搜索路径里移出，
                # 而 libdmcan.dll 还依赖 libusb-1.0.dll / libstdc++-6.dll 等。
                self._dll_directory = os.add_dll_directory(directory)
            self.dll = CDLL(self.dll_path, winmode=0)
        else:
            # 非 Windows 上 ctypes 不接受 winmode 参数
            self.dll = CDLL(self.dll_path)

        self._init_funcs()
        self.dll.dmcan_context_create(byref(self._ctx))
        if not self._ctx:
            # 2.1.0（2026-10-12 的更新）起库会把失败的真实原因写进 last_error：
            # 真·分配失败回 NO_MEMORY，其余（例如 USB 子系统初始化失败）回 INTERNAL 并在日志里给细节；
            # 此前一律报内存不足。这里必须**在 _check_abi() 之前**判空，否则空句柄会让版本查询失败，
            # 报出来的是"版本不配套"，把真正的原因盖掉。
            status = self.last_error()
            hint = ("" if status != dmcan_status.OK else
                    "（库未置错误码，细节见库日志；可用环境变量 DMCAN_LOG_LEVEL 提高日志级别）")
            raise RuntimeError(f"dmcan_context_create 失败：{status}{hint}（库路径：{self.dll_path}）")
        self._check_abi()

    def _bind(self, name: str, argtypes: list, restype) -> None:
        """
        @brief 绑定一个导出符号并声明参数/返回类型。

        @param name 符号名
        @param argtypes 参数类型列表
        @param restype 返回类型

        @note 符号缺失说明库与绑定不配套，这里直接给出明确报错，而不是留 AttributeError。
        """
        try:
            func = getattr(self.dll, name)
        except AttributeError as exc:
            raise RuntimeError(f"libdmcan 缺少符号 {name}：库与 dmcan {DMCAN_ABI_HINT} 绑定不配套") from exc
        func.argtypes = argtypes
        func.restype = restype

    def _init_funcs(self):

        self._bind("dmcan_context_create", [POINTER(POINTER(dmcan_context))], None)
        self._bind("dmcan_context_destroy", [POINTER(dmcan_context)], None)
        self._bind("dmcan_print_version", [POINTER(dmcan_context)], None)
        self._bind("dmcan_get_sdk_version", [POINTER(dmcan_context), POINTER(c_uint32)], None)

        self._bind("dmcan_find_devices", [POINTER(dmcan_context)], c_int)
        self._bind("dmcan_find_devices_with_type", [POINTER(dmcan_context), c_int], c_int)
        self._bind("dmcan_show_all_devices", [POINTER(dmcan_context)], None)
        self._bind("dmcan_device_get",
                   [POINTER(dmcan_context), POINTER(POINTER(dmcan_device_handle)), c_int], c_bool)

        self._bind("dmcan_get_last_error", [], c_int)
        self._bind("dmcan_clear_last_error", [], None)
        self._bind("dmcan_check_version", [c_uint32], c_bool)

        self._bind("dmcan_context_register_hotplug",
                   [POINTER(dmcan_context), HOTPLUG_CALLBACK, c_void_p], c_bool)
        self._bind("dmcan_context_unregister_hotplug", [POINTER(dmcan_context)], None)
        self._bind("dmcan_context_hotplug_supported", [POINTER(dmcan_context)], c_bool)

        self._bind("dmcan_utils_get_dlc_from_len", [c_int], c_int)
        self._bind("dmcan_utils_get_len_from_dlc", [c_int], c_int)

        self._bind("dmcan_set_log_level", [c_int], None)
        self._bind("dmcan_get_log_level", [], c_int)
        self._bind("dmcan_flush_log", [], None)
        self._bind("dmcan_add_log_callback",
                   [LOG_CALLBACK, c_int, c_void_p, POINTER(POINTER(dmcan_log_subscription))], c_bool)
        self._bind("dmcan_remove_log_callback", [POINTER(dmcan_log_subscription)], c_bool)

    def _check_abi(self) -> None:
        """
        @brief 校验库的版本与本绑定的结构体布局对得上。

        @note 判定口径是“主版本相等 且 次版本不低于绑定要求”：
              - 主版本变了 = ABI 不兼容（C 侧规矩），直接拒绝；
              - 次版本低于要求说明库太老（2.1 起 `dmcan_firmware_info_t` 已取代 `version_info_t`）；
              - 次版本更高按 C 侧规矩是“纯增量加接口”、结构体布局不动，可以继续用；
              - build / patch 号变化不影响布局，不看。
        """
        version = self.sdk_version_int()
        major, minor = version >> 24 & 0xFF, version >> 16 & 0xFF
        if major != DMCAN_ABI_MAJOR or minor < DMCAN_ABI_MINOR:
            self.destroy()
            raise RuntimeError(
                f"libdmcan 版本不配套：库是 {major}.{minor}.x，本绑定按 dmcan {DMCAN_ABI_HINT} 的"
                f"结构体布局解析（库路径：{self.dll_path}）")

    def sdk_version_int(self) -> int:
        """
        @brief 读库编译时写死的版本号（`dmcan_get_sdk_version`）。

        @return 32 位整数，低字节起依次是 patch / build / minor / major
        """
        version = c_uint32(0)
        self.dll.dmcan_get_sdk_version(self._ctx, byref(version))
        return version.value

    def sdk_version(self) -> str:
        """
        @brief 读库版本字符串，便于日志与报告记录被测版本。

        @return 形如 `2.0.1` 的字符串
        """
        version = self.sdk_version_int()
        return f"{version >> 24 & 0xFF}.{version >> 16 & 0xFF}.{version >> 8 & 0xFF}"

    def print_version(self) -> None:
        """@brief 让库把自己的版本打到日志里（`dmcan_print_version`）。"""
        if self._ctx:
            self.dll.dmcan_print_version(self._ctx)

    def last_error(self):
        """
        @brief 读本线程最后一次失败的错误码（`dmcan_get_last_error`，线程局部）。

        @return `dmcan_status` 成员；比本绑定新的未收录取值原样返回整数
        """
        return status_of(self.dll.dmcan_get_last_error())

    def _check(self, result, api: str) -> None:
        """
        @brief 统一的失败处理：C 侧返回 false 就按 `dmcan_get_last_error()` 抛 `DmCanError`。

        @param result C 接口的返回值
        @param api 接口名（报错信息里带上，便于定位）
        """
        if not result:
            raise DmCanError(self.last_error(), api)

    def find_devices(self, device_type: Optional[dmcan_device_type] = None) -> int:
        """
        @brief 刷新设备表并重建设备封装（`dmcan_find_devices`）。

        @param device_type 只找指定型号；`None` 表示不限
        @return 设备表里的设备总数 —— **含已拔掉的**（句柄表只增不销毁，判断在不在用
                `dmcan_device_is_present()`，本绑定尚未封装）

        @note 下标与 `get_device()` 一一对应：取句柄失败的槽位会被跳过，不会让后面的下标错位。
        """
        if self._ctx is None:
            return 0

        if device_type is None:
            count = self.dll.dmcan_find_devices(self._ctx)
        else:
            count = self.dll.dmcan_find_devices_with_type(self._ctx, int(device_type))

        self._devices.clear()
        for index in range(count):
            handle = POINTER(dmcan_device_handle)()
            if not self.dll.dmcan_device_get(self._ctx, byref(handle), index):
                continue
            if not handle:
                continue
            self._devices[index] = DmCanDevice(self.dll, handle, index)

        return count

    def show_all_devices(self) -> None:
        """@brief 让库把设备表打印出来（`dmcan_show_all_devices`）。"""
        if self._ctx is None:
            return
        self.dll.dmcan_show_all_devices(self._ctx)

    def get_device(self, index: int) -> DmCanDevice:
        """
        @brief 取 `find_devices()` 里下标为 `index` 的设备。

        @param index 设备表下标
        @return `DmCanDevice`

        @note 下标不存在（没调 `find_devices()` 或该槽位取句柄失败）会抛 `KeyError`。
        """
        return self._devices[index]

    def check_version(self, expected_version: int) -> bool:
        """
        @brief 校验库编译时的版本是否**等于** `expected_version`（`dmcan_check_version`）。

        @param expected_version 期望的版本整数，低字节起依次是 patch / build / minor / major
        @return True = 完全一致

        @note 这是严格相等：库升了 build 号（如 2.0.1 → 2.0.2）也会回 False。判"结构体布局是否
              兼容"用构造 `DmCanContext` 时的 major.minor 闸门即可，本接口用于记录与诊断。
        """
        return bool(self.dll.dmcan_check_version(expected_version))

    def clear_last_error(self) -> None:
        """@brief 把本线程的错误码清成 `dmcan_status.OK`（`dmcan_clear_last_error`）。"""
        self.dll.dmcan_clear_last_error()

    def hotplug_supported(self) -> bool:
        """
        @brief 本机 libusb 的原生热插拔能力是否可用（`dmcan_context_hotplug_supported`，诊断用）。

        @return True = 支持
        """
        return bool(self.dll.dmcan_context_hotplug_supported(self._ctx))

    def register_hotplug(self, callback: Callable[[Any, dmcan_hotplug_event, DmCanHotplugDevice], None]) -> None:
        """
        @brief 注册热插拔回调（`dmcan_context_register_hotplug`）。

        @param callback `callback(context, event, device)`；`event` 是 `dmcan_hotplug_event`，
               `device` 是 `DmCanHotplugDevice`（已从 C 结构拷出）

        @note 回调在 libusb 事件线程上**同步**执行，必须快速返回；不要在里面打开设备、枚举或落盘。
        @note **不要在回调里注销热插拔**（要等同线程回调返回，会死锁）。
        @note 一个上下文只有一个热插拔槽位，重复注册 = 覆盖；不认识的设备不会报事件。
        """
        @HOTPLUG_CALLBACK
        def wrapper(ctx_ptr, event, device_ptr, user_data):
            device = None
            if device_ptr:
                raw = device_ptr.contents
                device = DmCanHotplugDevice(device_type_of(raw.type), raw.vendor_id, raw.product_id,
                                            raw.bus_number, raw.port_number)
            callback(self, dmcan_hotplug_event._value2member_map_.get(event, event), device)

        self._hotplug_wrapper = wrapper
        self._check(self.dll.dmcan_context_register_hotplug(self._ctx, wrapper, None),
                    "dmcan_context_register_hotplug")

    def unregister_hotplug(self) -> None:
        """@brief 注销热插拔回调（`dmcan_context_unregister_hotplug`，可重复调用）。"""
        if self._ctx:
            self.dll.dmcan_context_unregister_hotplug(self._ctx)
            self._hotplug_wrapper = None

    def get_dlc_from_len(self, dlen: int) -> int:
        """
        @brief 长度 → DLC（`dmcan_utils_get_dlc_from_len`，向上取整到能装下它的最小 DLC）。

        @param dlen 字节长度
        @return DLC 码；越界（> 64 或负值）回 -1
        """
        return int(self.dll.dmcan_utils_get_dlc_from_len(dlen))

    def get_len_from_dlc(self, dlc: int) -> int:
        """
        @brief DLC → 长度（`dmcan_utils_get_len_from_dlc`）。

        @param dlc DLC 码
        @return 字节长度；越界（不在 0~15）回 -1
        """
        return int(self.dll.dmcan_utils_get_len_from_dlc(dlc))

    def set_log_level(self, level: int) -> None:
        """
        @brief 设置终端日志级别（`dmcan_set_log_level`）：0=trace 1=debug 2=info 3=warn 4=error 5=critical 6=off。

        @param level 级别；低于该级别的日志不再输出

        @note Release 构建默认把 trace/debug 裁剪掉，即使设到 trace 也拿不到那两级。
        """
        self.dll.dmcan_set_log_level(level)

    def get_log_level(self) -> int:
        """
        @brief 读当前终端日志级别（`dmcan_get_log_level`）。

        @return 0 ~ 6，含义见 `set_log_level()`
        """
        return int(self.dll.dmcan_get_log_level())

    def flush_log(self) -> None:
        """@brief 立即刷新日志缓冲（`dmcan_flush_log`；warn 及以上本来就会立即 flush）。"""
        self.dll.dmcan_flush_log()

    def add_log_callback(self, callback: Callable[[int, int, str], None],
                         min_level: int = 0) -> DmCanLogSubscription:
        """
        @brief 注册日志订阅，把日志交给用户自己落盘（`dmcan_add_log_callback`，最多 4 个）。

        @param callback `callback(level, seq, line)`；`line` 已拷成 `str`
        @param min_level 该回调自己的阈值（与终端级别互相独立，终端静音也能照收）
        @return `DmCanLogSubscription`；`cancel()` 注销

        @note 回调**同步执行在产生日志的线程上**：不要在回调里做重活（要落盘就自己攒队列），
              也不要再调 SDK 的日志接口（内部会丢弃重入日志）。
        """
        @LOG_CALLBACK
        def wrapper(level, seq, line, user_data):
            callback(int(level), int(seq), line.decode("utf-8", errors="replace") if line else "")

        subscription = POINTER(dmcan_log_subscription)()
        self._check(self.dll.dmcan_add_log_callback(wrapper, min_level, None, byref(subscription)),
                    "dmcan_add_log_callback")
        return DmCanLogSubscription(self.dll, subscription, wrapper)

    def remove_log_callback(self, subscription: DmCanLogSubscription) -> None:
        """
        @brief 注销日志订阅（`dmcan_remove_log_callback`）。

        @param subscription `add_log_callback()` 返回的句柄
        """
        self._check(self.dll.dmcan_remove_log_callback(subscription._subscription),
                    "dmcan_remove_log_callback")
        subscription._active = False

    def destroy(self) -> None:
        """@brief 销毁上下文（可重复调用）。"""
        if self._ctx:
            self.dll.dmcan_context_destroy(self._ctx)
            self._ctx = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        for device in self._devices.values():
            device.close()
        self.destroy()

    def __del__(self):
        if hasattr(self, "_ctx"):
            self.destroy()
