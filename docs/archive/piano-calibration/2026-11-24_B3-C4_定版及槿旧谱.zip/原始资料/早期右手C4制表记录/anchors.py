from pathlib import Path
import json
import numpy as np
from openarm_app.kinematics import OpenArmIK

root = Path.cwd()
temp = root / '.sim-temp' / 'piano-right-keys-20261122'
log = root / 'logs/openarm/monitor/hardware-e1f54c5aeb414f7c841823a3d5f4a4dd.jsonl'
ids = ['f2c4075df1f04d2ab8bfe1df112f0196', '6c768c5895a94e96926f50721704acd3']
encoded = [s.encode() for s in ids]
arm = OpenArmIK()
events = {rid: [] for rid in ids}
with log.open('rb') as stream:
    for i, line in enumerate(stream, 1):
        if any(rid in line for rid in encoded):
            r = json.loads(line)
            events[r['request_id']].append((i, r))

out = []
for rid, ev in events.items():
    fields = [(i, r) for i, r in ev if r['event'] == 'motion.sample' and 4 <= r['data']['t'] < 9]
    joints = np.array([r['data']['measured'][-7:] for i, r in fields])
    mid = np.median(joints, axis=0)
    idx = np.argmin(np.linalg.norm(joints-mid, axis=1))
    i, r = fields[idx]
    measured = joints[idx]
    goal = r['data']['target'][-7:]
    def pose(q):
        return (arm.forward(q)*[1000,1000,1000,1,1,1,1]).tolist()
    out.append(dict(request=rid, line=i, timestamp=r['timestamp'], target_q=goal,
                    measured_q=measured.tolist(), target_pose=pose(goal), measured_pose=pose(measured)))
    print(rid, i, r['timestamp'])
    for k in ['target','measured']:
        print(k, 'deg',np.rad2deg(out[-1][k+'_q']).round(3), 'FK',np.round(out[-1][k+'_pose'],5))
    print([(i,r['event'],str(r['data'])[:150]) for i,r in ev if r['event'] in ['motion.checkpoint','drive.holding']])
(temp / 'anchors.json').write_text(json.dumps(out),encoding='utf8')
