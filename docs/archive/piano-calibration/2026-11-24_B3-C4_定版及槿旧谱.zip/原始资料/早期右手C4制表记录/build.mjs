import fs from 'node:fs/promises';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath, pathToFileURL } from 'node:url';
const dir=path.dirname(fileURLToPath(import.meta.url));
const require=createRequire(path.join(process.argv[2],'artifact-loader.cjs'));
const {Workbook,SpreadsheetFile}=await import(pathToFileURL(require.resolve('@oai/artifact-tool')).href);
const sets=await Promise.all([1,2].map(async n=>JSON.parse(await fs.readFile(path.join(dir,'solved'+n+'.json'),'utf8'))));
const dest=path.join(process.cwd(),'openarm','skills','paino_skill');
const book=Workbook.create();
const tab=book.worksheets.add('逐键对照'), ref=book.worksheets.add('24键现场记录');
const bodyFont='Microsoft YaHei';
const colors={ink:'#153747', muted:'#466572',teal:'#12675F', blue:'#285575', pale:'#EDF4F5', accent:'#D6EFEB', faded:'#687D83'};
function rng(s,r){return s.getRange(r);}
function vals(s,r,v){rng(s,r).values=v;}
function line(s,address,value){
  const area=rng(s,address); area.merge(); area.values=[[value]];
}
function defaults(s,last){
  s.showGridLines=false;
  const a=rng(s,last);
  a.format.font={name:bodyFont,size:10,color:colors.ink};
  a.format.verticalAlignment='center'; a.format.rowHeight=18;
}
function title(s,address,value){
  line(s,address,value);rng(s,address).format.font={name:bodyFont,size:15,bold:true,color:colors.ink};
  rng(s,address).format.rowHeight=28;
}
function hdr(s,addr){
  const a=rng(s,addr);a.format.fill=colors.teal;a.format.font={name:bodyFont,color:'#FFFFFF',bold:true,size:10};
  a.format.horizontalAlignment='center';a.format.rowHeight=25;
}
function width(s,col,n){rng(s,col+'1:'+col+'70').format.columnWidthPx=n;}
const labels=['第一次 17:35','第二次 17:45'];
const note=k=>['A','B','C','D','E','F','G'][(k-1)%7]+Math.floor((k+4)/7);
const jointLabels=Array.from({length:7},(_,j)=>'J'+(j+1)+' (°)');
const headers=['白键','音名','24 键标定姿态','X (mm)','Y (mm)','Z (mm)',...jointLabels,'位置差 (mm)','朝向差 (°)','关节角来源'];
defaults(tab,'A1:P64');title(tab,'A2:P2','右手食指 · 白键悬停点位与右臂关节角');
line(tab,'A3:P3','白键 24 为 C4。X = 244.5 mm，Z = −177 mm。沿用原表键序，键号每增加 1，Y 减小 22.5 mm。');
line(tab,'A4:P4','每键两行，各自保持该次 24 键的目标腕部朝向。位置差与朝向差均为模型正解误差。两次实机反馈见「24键现场记录」。');
vals(tab,'A6:P6',[headers]);hdr(tab,'A6:P6');
const lateralOrder=[...Array.from({length:15},(_,i)=>24+i),...Array.from({length:14},(_,i)=>23-i)];
const out=[];
const csvHeaders=['arm','finger','key','note','anchor_run','anchor_time_local','offset_steps','delta_y_m','status','position_error_m','orientation_error_rad',...Array.from({length:7},(_,i)=>'q'+(i+1)), 'x_m','y_m','z_m','qw','qx','qy','qz',...Array.from({length:7},(_,i)=>'J'+(i+1)+'_deg'),'x_mm','y_mm','z_mm','anchor_request_id','coordinate_convention'];
const csv=[];
for(const [ki,k] of lateralOrder.entries()){
  for(const [i,data] of sets.entries()){
    const r=data.rows.find(v=>v.key===k),d=r.deg??Array(7).fill(null);
    const status=k===24?'现场 IK 指令':r.q?'离线 IK':'未找到收敛解';
    out.push([k,note(k),labels[i],...r.xyz,...d,r.mm??null,r.ang??null,status]);
    const xyzm=r.xyz.map(v=>v/1000);
    csv.push(['right','index',k,note(k),i+1,i===0?'2026-11-22 17:35':'2026-11-22 17:45',r.offset,-r.offset*.0225,
      k===24?'logged_ik_command':r.q?'offline_ik':'no_converged_ik',r.mm==null?null:r.mm/1000,r.ang==null?null:r.ang*Math.PI/180,
      ...(r.q??Array(7).fill(null)),...xyzm,...r.quat,...d,...r.xyz,data.anchor.request,data.version]);
  }
  const row=7+2*ki;
  if(ki===0 || ki%2===0)rng(tab,'A'+row+':P'+(row+1)).format.fill=ki===0?colors.accent:colors.pale;
}
vals(tab,'A7:P64',out);
rng(tab,'D7:F64').format.numberFormat='0.0';
rng(tab,'G7:M64').format.numberFormat='0.00';
rng(tab,'N7:O64').format.numberFormat='0.00000';
for(const [i,w] of [56,52,126,78,78,78,76,76,76,76,76,76,76,110,102,148].entries())width(tab,String.fromCharCode(65+i),w);
tab.freezePanes.freezeRows(6);
defaults(ref,'A1:N28');title(ref,'A2:N2','白键 24 · 两次现场 IK 与保持反馈');
line(ref,'A3:N3','右腕控制点 right_ee_control_point，相对于 arm_origin。两次均到达并保持相同目标 XYZ，现场指尖对键所对应的具体一次尚待辨认。');
vals(ref,'A5:L5',[['姿态','记录类型','X (mm)','Y (mm)','Z (mm)',...jointLabels]]);hdr(ref,'A5:L5');
const coarse=[8,0,0,90,0,0,2];
const sourceRows=[['粗定位','关节目标 / 模型 FK',244.515985,-152.499303,-187.798083,...coarse]];
for(const [i,data] of sets.entries()){
  const a=data.anchor;
  for(const type of ['target','measured']){
    sourceRows.push([labels[i],type==='target'?'IK 指令 / 模型 FK':'保持反馈 / 模型 FK',...a[type+'_pose'].slice(0,3),...a[type+'_q'].map(x=>x*180/Math.PI)]);
  }
}
vals(ref,'A6:L10',sourceRows);rng(ref,'A7:L8').format.fill=colors.accent;rng(ref,'A9:L10').format.fill=colors.pale;
rng(ref,'C6:L10').format.numberFormat='0.000';
line(ref,'A12:N12','各组 IK 锁定该次目标关节角对应的腕部朝向。下表为 arm_origin 坐标系中的目标四元数 (w, x, y, z)。');
vals(ref,'A13:E13',[['现场姿态','qw','qx','qy','qz']]);hdr(ref,'A13:E13');
vals(ref,'A14:E15',sets.map((g,i)=>[labels[i],...g.anchor.target_pose.slice(3)]));rng(ref,'B14:E15').format.numberFormat='0.00000000';
line(ref,'A17:N17','位置依据');
line(ref,'A18:N18','用户现场确认右食指位于白键 24 上方，腕部读数 (244.5, −33.5, −177) mm，相邻白键中心距 22.5 mm。高音方向采用原表的 −Y。');
line(ref,'A19:N19','其余白键推算式为 Y = −33.5 − 22.5 × (白键号 − 24) mm。键号沿用 points.csv 右臂 10–38，关节使用控制台逻辑角。');
line(ref,'A20:N20','24 键列出日志中的 IK 目标角，反馈另列。其余角度由官方 OpenArm V1 IK 从 24 键向两侧逐键求解。空白角度表示固定该朝向未找到收敛解。');
line(ref,'A21:N21','XYZ 均为腕部控制点。保持反馈的 XYZ 由同一时刻七轴反馈做正解得到。其他键的食指对中和落键尚待现场核实。');
line(ref,'A23:N23','实机日志 · 2026-11-22（北京时间）');
const logname='logs/openarm/monitor/hardware-e1f54c5aeb414f7c841823a3d5f4a4dd.jsonl';
line(ref,'A24:N24',logname);
for(const [i,g] of sets.entries()){
 const a=g.anchor; const time=new Date(a.timestamp).toLocaleTimeString('en-GB',{timeZone:'Asia/Shanghai',hour12:false});
 line(ref,'A'+(25+i)+':N'+(25+i),labels[i]+'　请求 '+a.request+'　保持反馈 '+time+'，日志第 '+a.line+' 行');
}
line(ref,'A27:N27','关节映射版本　'+sets[0].version);
for(const row of [17,23]){
 const s=rng(ref,'A'+row+':N'+row);s.format.fill=colors.pale;s.format.font={name:bodyFont,size:10,bold:true,color:colors.teal};
}
for(const [i,w] of [132,178,93,93,93,75,75,75,75,75,75,75,60,60].entries())width(ref,String.fromCharCode(65+i),w);
book.recalculate();
const check=await book.inspect({kind:'region',sheetId:tab.name,range:'A6:P10',maxChars:850,tableMaxRows:5,tableMaxCols:6});
console.log(check.ndjson);
const filebase='右手食指_实机白键点位与关节角_20261122';
const output=await SpreadsheetFile.exportXlsx(book);
await output.save(path.join(dest,filebase+'.xlsx'));
const csvEscape = val => {
  if(val==null)return '';
  const s=String(val);return /[",\r\n]/.test(s)?'"'+s.replaceAll('"','""')+'"':s;
};
csv.sort((a,b)=>a[2]-b[2]||a[4]-b[4]);
await fs.writeFile(path.join(dest,filebase+'.csv'),'\uFEFF'+[csvHeaders,...csv].map(row=>row.map(csvEscape).join(',')).join('\r\n')+'\r\n','utf8');
for(const [sheet,range,fn] of [[tab,'A1:P14','points'],[ref,'A1:N27','anchor']]){
 const preview=await book.render({sheetName:sheet.name,range,scale:.9,format:'png'});
 await fs.writeFile(path.join(dir,fn+'.png'),new Uint8Array(await preview.arrayBuffer()));
}
