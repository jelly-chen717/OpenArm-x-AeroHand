from pathlib import Path
import csv
import json
import math
import zipfile
from xml.etree import ElementTree as ET

import mujoco
import numpy as np
from openarm_app.kinematics import OpenArmIK

root=Path.cwd()
dest=root / 'openarm/skills/paino_skill'
name='右手食指_实机白键点位与关节角_20261122'
def csvread(path):
    with path.open(encoding='utf-8-sig',newline='') as f:
        return list(csv.DictReader(f))
def sheet(z,n):
    ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
    strings=z.read('xl/sharedStrings.xml') if 'xl/sharedStrings.xml' in z.namelist() else b'<root/>'
    shared=[''.join(x.itertext()) for x in ET.fromstring(strings)]
    cells={}
    tree=ET.fromstring(z.read(f'xl/worksheets/sheet{n}.xml'))
    for c in tree.findall('.//m:sheetData/m:row/m:c',ns):
        v=c.findtext('m:v',namespaces=ns)
        if c.get('t')=='inlineStr':
            val=''.join(c.find('m:is',ns).itertext())
        elif v is None: continue
        elif c.get('t')=='s': val=shared[int(v)]
        elif c.get('t')=='str': val=v
        elif c.get('t')=='e': raise ValueError(v)
        else: val=float(v)
        cells[c.attrib['r']]=val
    return cells
with zipfile.ZipFile(dest / (name+'.xlsx')) as z:
    assert z.testzip() is None
    xls,ref=sheet(z,1),sheet(z,2)
rows=csvread(dest / (name+'.csv'))
original=csvread(dest / 'points.csv')
source_keys={int(r['key']) for r in original if r['arm']=='right'}
assert len(rows)==len(source_keys)*2==58
assert len({(r['key'],r['anchor_run']) for r in rows})==58
assert {int(r['key']) for r in rows}==source_keys
lookup={(int(r['key']),int(r['anchor_run'])):r for r in rows}
anchor=json.loads((Path(__file__).parent/'anchors.json').read_text())
ik=OpenArmIK()
model=ik.setup.model
data=mujoco.MjData(model)
origin=model.site('arm_origin').id
wrist=model.site('right_ee_control_point').id
qadr=[int(model.joint('openarm_right_joint'+str(j)).qposadr[0]) for j in range(1,8)]
maxmm=maxang=0.
solved={1:[],2:[]}
notes=[m for m in range(21,109) if m%12 in {0,2,4,5,7,9,11}]
for i in range(7,65):
    key=int(xls['A'+str(i)])
    run=1 if xls['C'+str(i)].startswith('第一次') else 2
    r=lookup.pop((key,run))
    target=np.array([244.5,-33.5-22.5*(key-24),-177.])
    midi=notes[key-1]
    note=['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'][midi%12]+str(midi//12-1)
    assert r['note']==xls['B'+str(i)]==note
    assert r['arm']=='right' and r['finger']=='index' and r['anchor_request_id']==anchor[run-1]['request']
    assert np.allclose([float(r[a+'_mm']) for a in 'xyz'],target)
    assert np.allclose([float(r[a+'_m'])*1000 for a in 'xyz'],target)
    assert np.allclose([xls[col+str(i)] for col in 'DEF'],target)
    assert math.isclose(float(r['delta_y_m'])*1000,target[1]+33.5,abs_tol=1e-10)
    quat=np.array([float(r['q'+c]) for c in 'wxyz'])
    assert np.allclose(quat,anchor[run-1]['target_pose'][3:],rtol=0,atol=1e-10)
    if r['status']=='no_converged_ik':
        assert xls['P'+str(i)]=='未找到收敛解'
        assert all(not r['q'+str(j)] and not r['J'+str(j)+'_deg'] for j in range(1,8))
        assert not r['position_error_m'] and not r['orientation_error_rad']
        assert all(col+str(i) not in xls for col in 'GHIJKLMNO')
        continue
    assert xls['P'+str(i)]==('现场 IK 指令' if key==24 else '离线 IK')
    q=np.array([float(r['q'+str(j)]) for j in range(1,8)])
    deg=np.array([float(r['J'+str(j)+'_deg']) for j in range(1,8)])
    assert np.all(q>=ik.limits[:,0]) and np.all(q<=ik.limits[:,1])
    assert np.allclose(np.rad2deg(q),deg,atol=1e-10,rtol=0) and np.allclose(deg,[xls[c+str(i)] for c in 'GHIJKLM'])
    if key==24:
        assert np.array_equal(q,anchor[run-1]['target_q'])
        assert np.allclose(deg,[ref[c+str(7+(run-1)*2)] for c in 'FGHIJKL'])
        assert np.allclose(np.rad2deg(anchor[run-1]['measured_q']),[ref[c+str(8+(run-1)*2)] for c in 'FGHIJKL'])
    data.qpos[qadr]=q
    mujoco.mj_kinematics(model,data)
    rot=data.site_xmat[origin].reshape(3,3)
    pos=rot.T @ (data.site_xpos[wrist]-data.site_xpos[origin])*1000
    rot_actual=rot.T @ data.site_xmat[wrist].reshape(3,3)
    rot_target=np.empty(9);mujoco.mju_quat2Mat(rot_target,quat)
    ang=np.rad2deg(np.arccos(np.clip((np.trace(rot_target.reshape(3,3).T @ rot_actual)-1)*.5,-1,1)))
    mm=np.linalg.norm(pos-target)
    assert abs(mm-1000*float(r['position_error_m']))<.00012 and abs(ang-np.rad2deg(float(r['orientation_error_rad'])))<.00012, (key,run,mm,ang)
    assert abs(xls['N'+str(i)]-float(r['position_error_m'])*1000)<1e-10
    assert abs(xls['O'+str(i)]-np.rad2deg(float(r['orientation_error_rad'])))<1e-10
    maxmm=max(maxmm,mm);maxang=max(maxang,ang);solved[run].append(key)
assert not lookup
print('58 CSV/XLSX rows verified. Per-run solved white keys:',{n:sorted(v) for n,v in solved.items()})
print('Independent MuJoCo FK maximum residuals:',maxmm,'mm,',maxang,'deg')
