import csv
import json
import sys
from pathlib import Path
import numpy as np
from openarm_app.kinematics import OpenArmIK
from openarm_app.kinematics.openarm_ik import IKConvergenceError, pose_error
from openarm_app.joint_convention import CONVENTION_VERSION

base = Path.cwd()
temp = Path(__file__).resolve().parent
piano = base / 'openarm/skills/paino_skill'
anchor_no = int(sys.argv[1])
anchor = json.loads((temp / 'anchors.json').read_text())[anchor_no-1]
with (piano / 'points.csv').open(encoding='utf-8-sig',newline='') as stream:
    keys = sorted(int(r['key']) for r in csv.DictReader(stream) if r['arm'] == 'right')
arm = OpenArmIK()
q0 = np.array(anchor['target_q'])
at24 = arm.forward(q0)
at24[:3] = [.2445,-.0335,-.177]
low,high=arm.limits.T
rng = np.random.default_rng(0)
random_starts = low + rng.uniform(.1,.9,(8,7)) * (high-low)
rows = {}
tight = (.00002,.00015)
normal = (.0002,np.deg2rad(.1))
console = (.001,.003)
for direction in (-1,1):
    seed = q0.copy()
    earlier = None
    for key in sorted([k for k in keys if direction*(k-24)>=0],reverse=direction<0):
        pose = at24.copy()
        pose[1] -= (key-24)*.0225
        extrapolated = seed if earlier is None else np.clip(2*seed-earlier,low,high)
        joint = q0 if key == 24 else None
        tries = 0
        if joint is None:
            candidates = [extrapolated,seed,q0,arm.home,(low+high)/2]
            swivel = np.array([0,0,1,0,-1,0,0])
            candidates.extend(np.clip(seed+s*swivel,low,high) for s in np.deg2rad([-45,-20,20,45]))
            candidates.extend(random_starts)
            seen=set()
            fallback=[]
            for st in candidates:
                if tuple(st) in seen:
                    continue
                seen.add(tuple(st))
                tries+=1
                try:
                    solved=arm.inverse(pose,st,max_iterations=100,
                            position_tolerance=console[0], orientation_tolerance=console[1])
                except IKConvergenceError:
                    continue
                try:
                    solved=arm.inverse(pose,solved,max_iterations=150,
                        position_tolerance=tight[0],orientation_tolerance=tight[1])
                except IKConvergenceError:
                    try:
                        solved=arm.inverse(pose,solved,max_iterations=100,
                            position_tolerance=normal[0],orientation_tolerance=normal[1])
                    except IKConvergenceError:
                        pass
                fallback.append(solved)
                if np.max(np.abs(seed-solved)) < np.deg2rad(30):
                    break
            if fallback:
                joint=min(fallback,key=lambda q: np.linalg.norm(q-seed))
        row=dict(key=key,offset=key-24,xyz=(1000*pose[:3]).round(6).tolist(),quat=pose[3:].tolist(), tries=tries)
        if joint is not None:
            err_p,err_o=pose_error(arm.forward(joint),pose)
            assert err_p<=console[0] and err_o<=console[1]
            row.update(q=joint.tolist(),deg=np.rad2deg(joint).tolist(),mm=1000*err_p,ang=np.rad2deg(err_o))
            earlier,seed=seed,joint
        rows[key]=row
        print(key,('ok %.6f mm'%row['mm']) if joint is not None else 'no solution',tries,flush=True)
out=[rows[k] for k in keys]
(temp / f'solved{anchor_no}.json').write_text(json.dumps(dict(rows=out,version=CONVENTION_VERSION,anchor=anchor)),encoding='utf8')
